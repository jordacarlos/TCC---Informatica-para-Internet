
  <link href="./Scripts/sobre.css" rel="stylesheet">

  <br><br><br><br><br><br>
  <center><h1>Quem Somos?</h1></center>
  <br>

  <div class="card col-md-9 mt-5 mb-5">
  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-interval="100000">
    <div class="w-100 carousel-inner" role="listbox">
      <div class="carousel-item active">
        <div class="carousel-caption">
          <div class="row">
            <div class="col-sm-3">
              <img src="./imgs/sobre/bruno.png" alt="" class="rounded-circle img-fluid" style="width: 300px;" />
            </div>
            <div class="col-sm-9">
              <h3>Bruno Rodrigues Lucas</h3>
              <p>Desenvolvedor Back-end. PhP, Lógica, Integração Banco de dados </p>
            </div>
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <div class="carousel-caption">
          <div class="row">
            <div class="col-sm-3">
              <img src="./imgs/sobre/jorda.png" alt="" class="rounded-circle img-fluid" style="width: 300px;">
            </div>
            <div class="col-sm-9">
              <h3>Jordã Carlos de Jesus</h3>
              <p>Desenvolvedor front-end. HTML, CSS, JavaScript</p>
            </div>
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <div class="carousel-caption">
          <div class="row">
            <div class="col-sm-3">
              <img src="./imgs/sobre/julia.png" alt="" class="rounded-circle img-fluid" style="width: 300px;">
            </div>
            <div class="col-sm-9">
              <h3>Julia Santos Rocha</h3>
              <p>Documentação, criação de idéias, HTML, CSS.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <div class="carousel-caption">
          <div class="row">
            <div class="col-sm-3">
              <img src="./imgs/sobre/Liandra.png" alt="" class="rounded-circle img-fluid" style="width: 300px;" />
            </div>
            <div class="col-sm-9">
              <h3>Liandra Wanzeller de Melo</h3>
              <p>Designer, Criação Banco de Dados, Documentação</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="float-right navi">
    <a class="" href="#carouselExampleControls" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon ico" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="" href="#carouselExampleControls" role="button" data-slide="next">
      <span class="carousel-control-next-icon ico" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
    </div>
  </div>
</div>
    <br>
    <div class="container">
      <h2 id="porq">Por que Prontuário Digital?</h2>
      <br>
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-12 text-center my-5">
          <div class="card" id="cardqs" >
            <div class="card-body" id="pqtext">
                <center><h3 class="card-title">Ideia principal:</h3></center>
              <p class="card-text">A ideia gira ao redor da ideia de criar um sistema web que facilitaria a Triagem dos hospitais, exames pre consulta para identificar o problema.</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12 text-center my-5">
          <div class="card" id="cardqs">
            <div class="card-body" id="pqtext" >
                <center><h3 class="card-title">Desenvolvimento:</h3></center>
              <p class="card-text">A criação do site não se mostrou um grande desafio, porém foi preciso ir em busca de algumas ferramentas para fazer aquilo que pensamos inicialmente.</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12 text-center my-5">
          <div class="card" id="cardqs">
            <div class="card-body" id="pqtext">
              <center><h3 class="card-title">Desafios:</h3></center>
              <p class="card-text">Alguns dos desafios do projeto forem a desistência de alguns participantes do grupo,ainda assim, conseguimos entregar aquilo que planejamos.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <br><br><br><br><br>
      <div class="container">
            <div class class="col-md-12">
              <div class="jumbotron jumbotron-fluid" id="agd">
                <div class="container">
                  <h1 class="display-4" id="titagd">Agradecimentos</h1>
                  <p class="lead" id="txtagd">Agradecemos todos os professores,no desenvolvimento do trabalho, como os Profrs: Jackson, André, Fabricio, Denis.</p>
                </div>
              </div>
            </div>
          </div>
    </div>
    <Br><Br>


