<!-- Funcionalidades -->
		<br><br><br><br><br><br>
		<div class="container">
			<center>
			<h1>Funcionalidades</h1>
			</center>
		<br>
		<br>
		<p class = "lead">
			O Prontuário Digital é um sistema web criado para melhorar e aumentar a velocidade no atendimento de todos os pacientes que venham a utilizar o sistema. Tendo uma navegação intuitiva e fácil para qualquer um, visando à mobilidade e acessibilidade de informações para qualquer lugar, sem que haja dores de cabeça em lembrar a qual remédio você é alérgico ou quais tratamentos anda fazendo. Utilizando o Prontuário de maneira regular, seus problemas de espera nos hospitais vão acabar. Conheça algumas funcionalidades do site abaixo:
		</p>
		</div>
    <br>

    <!-- Funcionalidades  (texto e icone e/ou foto) -->
    <div class = "container" id="container">
        <div class="card-deck">
          
          <div class="col-sm-4">
            <div class="card">
              <div class="card-body">
        				<center>
        					<img  src="./Imgs/func/minha.png" class="img-fluid"  alt="Card image cap" width="180px" width="180px">
        					<h4 class="card-title">Minha Saúde</h4>
        				</center>
                <p>No Minha Saúde adicione, edite e exclua informações sobre você. Suas alergias, doenças, coloque tudo a seu respeito para preencher seu Prontuário Digital.
                </p>
                <a href="#" class="btn btn-primary">Leia mais...</a>
              </div>
            </div>
          </div>

          <div class="col-sm-4">
            <div class="card">
              <div class="card-body">
                <center>
                  <img src="./Imgs/func/agenda.png" class="img-fluid"  alt="Card image cap" width="180px" width="180px">
                  <h4 class="card-title">Agenda</h4>
                </center>
                <p class="card-text">Veja sua Agenda para o mês, marque ou consulte suas próximas visitas ao medico ou compromissos.                                  
                </p>
                <br>
                <br>
                <a href="#" class="btn btn-primary">Leia mais...</a>
              </div>
            </div>
          </div>

          <div class="col-sm-4">
            <div class="card">
              <div class="card-body">
	              <center>
                  <img src="./Imgs/func/remedio.png" class="img-fluid"  alt="Card image cap" width="180px" width="180px">
            		  <h4 class="card-title">Medicamentos</h4>
            		</center>
                  <p class="card-text">Tem dificuldades de achar algum medicamento ou não lembra o nome, aqui você pode anotar os remédios mais usados e consultar aonde comprar mais perto da sua casa.
                  </p>
                  <a href="#" class="btn btn-primary">Leia mais...</a>
             </div>
            </div>
          </div>

            

        </div>
        <br><br>
        <div class="card-deck">

            <div class="col-sm-4">
              <div class="card">
                <div class="card-body">
		              <center>
                    <img  src="./Imgs/func/servico.png" class="img-fluid" alt="Card image cap" width="180px" width="180px">
                    <h4 class="card-title">Serviços de Saúde</h4>
            		  </center>
                  <p class="card-text">Localize os serviços que você mais precisa na sua região consultando nosso mapa, sem dores de cabeça.
                  </p>
                <br>
                <br>
                  
                  <a href="#" class="btn btn-primary">Leia mais...</a>
               </div>
              </div>
            </div>

            <div class="col-sm-4">
              <div class="card">
                <div class="card-body">
            		 <center>
                    <img src="./Imgs/func/phone.png" class="img-fluid" alt="Card image cap" width="180px" width="180px">
                    <h4 class="card-title">Ouvidoria</h4>
            		  </center>
                  <p class="card-text">Temos alguns telefones para te ajudar, caso não ache o que precise no site ou algum serviço mais específico pode consultar alguns números para ser atendido.
                  </p>
                  <a href="#" class="btn btn-primary">Leia mais...</a>

                </div>
              </div>
            </div>

            <div class="col-sm-4">
              <div class="card">
                <div class="card-body">
  		            <center>
                    <img src="./Imgs/func/hospitais.png" class="img-fluid" alt="Card image cap" width="180px" width="180px">
                    <h4 class="card-tile">Hospitais</h4>
                  </center>
  		            <p class="card-text">Ache os hospitais mais próximos de você para qualquer emergência com a ajuda do nosso mapa de forma simples e rápida.
                  </p>
                <br>

                  <a href="#" class="btn btn-primary">Leia mais...</a>
                </div>
              </div>
            </div>
          </div>


      </div>
      <br><br>

          
<script>
    $(document).ready(function(){

        $('.col-sm-4').hover(
            // trigger when mouse hover
            function(){
                $(this).animate({
                    marginTop: "-=1%",
                },200);
            },

            // trigger when mouse out
            function(){
                $(this).animate({
                    marginTop: "0%"
                },200);
            }
        );
    });
</script>
