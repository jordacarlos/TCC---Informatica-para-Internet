
    <Br><Br><Br><Br>
      <div class="jumbotron jumbotron-fluid" id="jumbo_princ">
        <div class="container">
          <h1 class="display-4" id="txt_jumb">Prontuário Digital</h1>
          <p class="lead">Todo seu histórico médico mais rápido</p>
          <br>
          <a href="#loginModal" data-toggle="modal"><input type="button" value="Entrar" class="btn btn-primary" id="btn-banner"></input></a>
          <br><br><br><br>
        </div>
      </div>
      <div class="container-fluid">
        <Br><Br>
        <center>
          <h2>Serviços</h2>
        </center>
        <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-12 text-center my-5">
            <div class="card">
              <div class="card-body">
                <img src="./Imgs/index/Ouvidoria.png" width="70" id="ouvidoriascs">
                <h5 class="card-title">Ouvidoria</h5>
                <p class="card-text">Disponibilizar ajuda via telefone para qualquer dúvida ou emergência que você possa ter.</p>
              </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12 text-center my-5">
          <div class="card">
            <div class="card-body">
              <img src="./Imgs/index/localização.png" width="70" id="localizaçãoscs">
              <h5 class="card-title">Localização</h5>
              <p class="card-text">Procurar ou achar hospitais se tornará fácil usando o Prontuário Digital, sem mais dores de cabeça.</p>
            </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12 text-center my-5">
        <div class="card">
          <div class="card-body">
            <img src="./Imgs/index/logo-coracao.png" width="70" id="saudescs">
            <h5 class="card-title">Saúde</h5>
            <p class="card-text">Cuidar da sua saúde de forma pratica e digital, sem precisar as vezes levantar da cama.</p>
          </div>

      </div>
    </div>
      </div>
    </div>
    <Br><Br>
      <!--Propaganda site-->
      <div class>
        <div class="jumbotron jumbotron-fluid" id="jumbo_mid">
          <div class="container">
            <h1 class="display-4" id="textopalma">Na palma da mão</h1>
            <p class="lead" id="textopalma">Tudo a distância de um click </p>
          </div>
        </div>
      </div>
      <Br><Br>
      <div class="container-fluid">
          <center>
            <h2>Motivação</h2>
          </center>
          <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12 text-center my-5">
              <div class="card" id="mtvCard">
                <div class="card-body">
                  <img src="./Imgs/index/Planeta.jpg" width="70" id="imgplaneta">
                  <h5 class="card-title">Natureza</h5>
                  <p class="card-text">Ajudando não só nossos usuários, o projeto tem como interesse diminuir o ataque indireto da saúde ao meio ambiente.</p>
                </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-12 text-center my-5">
            <div class="card" id="mtvCard">
              <div class="card-body">
                <img src="./Imgs/index/velocidade.png" width="70" id="imgvelocidade">
                <h5 class="card-title">Velocidade</h5>
                <p class="card-text">Procurar melhorar e aumentar a agilidade dos atentimentos ao redor do Brasi, fazendo com que, a saude melhore para todos.</p>
              </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 text-center my-5">
          <div class="card" id="mtvCard">
            <div class="card-body">
              <img src="./Imgs/index/qualidade.png" width="88" id="imgqualidade">
              <h5 class="card-title">Qualidade</h5>
              <p class="card-text">Queremos entregar uma boa experiência para nossos usuários, com o foco principal na qualidade do projeto,para uma boa experiência</p>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 text-center my-5">
          <div class="card" id="mtvCard">
            <div class="card-body">
              <img src="./Imgs/index/semrestricao.png" width="70" id="semrestricao">
              <h5 class="card-title">Sem restrições</h5>
              <p class="card-text">Um software simples que abranja todas as pessoas que queiram utilizar o sistema, sem fazer escolhas de quem deve usar.</p>
            </div>
          </div>
        </div>
        </div>
        <center>
          <a href="./index.php?selec=s"><input type="button" value="Sobre nós" class="btn btn-primary" id="mtvBtn"></input></a>
        </center>
      </div>
      <Br><Br>
        <div class="jumbotron" id="jumboEnd">
          <h1 class="display-4">Agora só falta você</h1>
          <p class="lead">Venha fazer parte do Prontuário Digital, e nunca mais tenha dor de cabeça nos hospitais.</p>
          <p class="lead">
          <a href="#loginModal" data-toggle="modal"><input type="button" value="Entrar" class="btn btn-primary" id="btnCadastro"></input></a>
          </p>
        </div>
