<?php

$exame = addslashes($_POST['campo_0']);
$data = addslashes($_POST['campo_1']);
$realizado = addslashes($_POST['campo_3']);
$resultado = addslashes($_POST['campo_2']);

echo $exame . ' ' . $data . ' '. $realizado . ' '. $resultado; 


?>