<br><br><br><br> <br>
<center>
	<h1 class="bemvindo">Bem-Vindo <?php  echo $_SESSION["usr_name"];?>!</h1>
</center>
<style>
    .bemvindo {
        font-weight: bold;
        color: #585858;
    }
</style>