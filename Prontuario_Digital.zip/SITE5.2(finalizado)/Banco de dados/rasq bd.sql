create database prontuario_digital;

use prontuario_digital;

create table usuario (
  id_user int(11) primary key auto_increment,
  name_user varchar(30) not null,
  sobname_user varchar(100),
  data_user varchar (15),
  sexo_user varchar(1),
  login_user varchar(70) not null,
  email_user varchar(70) not null,
  senha_user varchar(100) not null,
  rg_user varchar (15),
  cpf_user varchar (15),
  orgao_exp varchar (15),
  cart_cidad varchar (30),
  cep_user varchar (15),
  numero_user varchar(6),
  rua_user varchar (100),
  bairro_user varchar (100),
  cidade_user varchar (100),
  estado_user varchar (100),
  tel_cel varchar (15),
  tel_resid varchar (15)
);

select * from usuario;

insert into usuario values (null,'Bruno','Rodrigues Lucas','30/03/2000','M','brunorl','bruno@email.com','90b9aa7e25f80cf4f64e990b78a9fc5ebd6cecad','12.345.678-9','123.456.789-10','USS/SP','1.123213123.11','13184-470','750','Cap. Lorival Mey','Remanso Campineiro','Hortolândia','São Paulo','(19) 99889-9889','(19) 3828-4321');
insert into usuario values (null,'Liandra','Wanzeller De Melo Da Silva','10/03/2000','F','liandrawms','liandra@email.com','90b9aa7e25f80cf4f64e990b78a9fc5ebd6cecad','12.345.678-9','123.456.789-10','USS/SP','1.123213123.11','13184-470','750','Cap. Lorival Mey','Remanso Campineiro','Hortolândia','São Paulo','(19) 99889-9889','(19) 3828-4321');
insert into usuario values (null,'Jordã','Carlos de Jesus','00/00/2000','M','jordacj','jorda@email.com','90b9aa7e25f80cf4f64e990b78a9fc5ebd6cecad','12.345.678-9','123.456.789-10','USS/SP','1.123213123.11','13184-470','750','Cap. Lorival Mey','Remanso Campineiro','Hortolândia','São Paulo','(19) 99889-9889','(19) 3828-4321');
insert into usuario values (null,'Julia','Santos Rocha','00/00/2000','F','juliasr','julia@email.com','90b9aa7e25f80cf4f64e990b78a9fc5ebd6cecad','12.345.678-9','123.456.789-10','USS/SP','1.123213123.11','13184-470','750','Cap. Lorival Mey','Remanso Campineiro','Hortolândia','São Paulo','(19) 99889-9889','(19) 3828-4321');

create table consulta (
	id_consu int (100) primary key auto_increment,
    nome_consu varchar (300),
    data_consu varchar (15),
    resut_consu varchar (300),
    realiz_consu varchar (15)
);

select * from consulta;
SELECT id_consu, nome_consu, data_consu, resut_consu, realiz_consu FROM consulta LIMIT 5;