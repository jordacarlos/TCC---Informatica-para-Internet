<script language="javascript">

function FrmValidaCadastro()
{
  var retorno = false;
  if(document.FrmCadastro.vNome.value == null || document.FrmCadastro.vNome.value == "")
  {
      alert("Por favor, preencher o campo Nome");
      document.FrmCadastro.vNome.focus();
      
  }
  else if(document.FrmCadastro.vNome.value.length < 3)
  {
      alert("Preencha o nome corretamente");
      document.FrmCadastro.vNome.focus();
  }
  else if(document.FrmCadastro.vLNome.value == null || document.FrmCadastro.vLNome.value == "")
  {
      alert("Por favor, preencher o campo Sobrenome");
      document.FrmCadastro.vLNome.focus();
      
  }
  else if(document.FrmCadastro.vLNome.value.length < 3)
  {
      alert("Preencha o sobrenome corretamente");
      document.FrmCadastro.vLNome.focus();
  }
  else if(document.FrmCadastro.vData.value == null || document.FrmCadastro.vData.value=="" || document.FrmCadastro.vData.value.length < 10)
  {
    alert("Por favor, preencher o campo Data de Nascimento");
    document.FrmCadastro.vData.focus();
  }
  else if(document.FrmCadastro.vSexo.value == 0)
  {
    alert("Por favor, preencher campo Sexo");
    document.FrmCadastro.vSexo.focus();
  }
  else if(document.FrmCadastro.vLogin.value == null || document.FrmCadastro.vLogin.value=="")
  {
      alert("Por favor, preencher o campo Login");
      document.FrmCadastro.vLogin.focus();
  }
  else if(document.FrmCadastro.vLogin.value.length < 3)
  {
      alert("Por favor, preencher o campo Login com ao menos 3 caracteres");
      document.FrmCadastro.vLogin.focus();
  }
  else if(document.FrmCadastro.vSenha.value == null || document.FrmCadastro.vSenha.value=="")
  {
      alert("Por favor, preencher o campo Senha");
      document.FrmCadastro.vSenha.focus();
  }
  else if(document.FrmCadastro.vSenha.value.length < 8)
  {
      alert("A senha deve possuir ao menos 8 caracteres");
      document.FrmCadastro.vSenha.focus();
  }
  else if(document.FrmCadastro.vSenha2.value == null || document.FrmCadastro.vSenha2.value=="")
  {
      alert("Por favor, Repetir a Senha");
      document.FrmCadastro.vSenha2.focus();
  }
  else if(document.FrmCadastro.vSenha.value != document.FrmCadastro.vSenha2.value)
  {
      alert("Senhas não se conhecidem");
      document.FrmCadastro.vSenha.focus();
  }
  else if(document.FrmCadastro.vEmail.value == null || document.FrmCadastro.vEmail.value=="")
  {
    alert("Por favor, preencher campo Email");
    document.FrmCadastro.vEmail.focus();

  }
  else if(document.FrmCadastro.vEmail2.value == null || document.FrmCadastro.vEmail2.value=="")
  {
    alert("Por favor, Repetir o Email");
    document.FrmCadastro.vEmail.focus();

  }
  else if(document.FrmCadastro.vEmail.value != document.FrmCadastro.vEmail2.value)
  {
      alert("Os emails não se conhecidem");
      document.FrmCadastro.vEmail.focus();
  }
  else if(document.FrmCadastro.vRG.value == null || document.FrmCadastro.vRG.value=="")
  {
    alert("Por favor, preencher campo RG");
    document.FrmCadastro.vRG.focus();
  }
  else if(document.FrmCadastro.vCPF.value == null || document.FrmCadastro.vCPF.value=="")
  {
    alert("Por favor, preencher campo CPF");
    document.FrmCadastro.vCPF.focus();
  }
  else if(document.FrmCadastro.vOrgaoexp.value == null || document.FrmCadastro.vOrgaoexp.value=="")
  {
    alert("Por favor, preencher campo Órgão Exp:");
    document.FrmCadastro.vOrgaoexp.focus();
  }
  else if(document.FrmCadastro.vCEP.value == null || document.FrmCadastro.vCEP.value=="")
  {
    alert("Por favor, preencher campo CEP");
    document.FrmCadastro.vCEP.focus();

  }
  else if(document.FrmCadastro.vNumero.value == null || document.FrmCadastro.vNumero.value=="")
    {
      alert("Por favor, preencher campo Número");
      document.FrmCadastro.vNumero.focus();

    }
  else if(document.FrmCadastro.vTelCel.value == null || document.FrmCadastro.vTelResi.value==null)
  {
    alert("Por favor, Telefone celular");
    document.FrmCadastro.vTelCel.focus();

  }
  else 
  {
    retorno = true;
    document.FrmCadastro.action='./index.php?acao=cadastro';
    document.FrmCadastro.submit();
  }
    return retorno;
}
</script>
<div class="container">
  <br><br><br><br><br>
  <h1>Dados Pessoais </h1>
  <form id="FrmCadastro" name="FrmCadastro" method="POST" action="">

	         <div class="form-row">
		           <div class="col form-group col-md-3">
			              <label>Nome:</label>
	  	              <input type="text" class="form-control " maxlength="15" placeholder=""  id="vNome" name="vNome" value="">
		           </div>
               <div class="col form-group col-md-4">
                    <label>Sobrenome:</label>
                    <input type="text" class="form-control " maxlength="400" placeholder=""  id="vLNome" name="vLNome" value="">
               </div>
		           <div class="col form-group col-md-3">
			             <label>Data de Nascimento:</label>
  	               <input type="text" class="form-control "  maxlength="8" placeholder="DD/MM/AAAA" id="vData" name="vData" value="">
		          </div>
              <div class="col form-group col-md-2">
                <label>Sexo:</label>
                  <select class="form-control" id="vSexo" name="vSexo">
                    <option value="0">Selecione</option>
                    <option value="M">M</option>
                    <option value="F">F</option>
                  </select>
              </div>
	           </div>
             <div class="form-row">
               <div class="col form-group">
                    <label>Login:</label>
                       <input type="text" class="form-control" maxlength="40" placeholder=""  id="vLogin" name="vLogin" value="">
               </div>
               <div class="col form-group">
                    <label>Senha</label>
                       <input type="password" class="form-control" placeholder=" " id="vSenha" name="vSenha" value="">
              </div>
              <div class="col form-group">
                    <label>Repita Senha</label>
                       <input type="password" class="form-control" placeholder=" " id="vSenha2" name="vSenha2" value="">
              </div>
             </div>
             <div class="form-row">
                  <div class="col form-group">
                         <label>E-mail:</label>
                            <input type="text" class="form-control"  maxlength="40" placeholder=" " id="vEmail" name="vEmail" value="">
                  </div>
                  <div class="col form-group">
                         <label>Repita o E-mail:</label>
                            <input type="text" class="form-control"  maxlength="40" placeholder=" " id="vEmail2" name="vEmail2" value="">
                  </div>
              </div>
              <div class="form-row">    
  		            <div class="col form-group">
  			              <label>RG:</label>
  		  	               <input type="text" class="form-control" maxlength="12" placeholder="" id="vRG" name="vRG" value="">
  		            </div>
                  <div class="col form-group">
                      <label>CPF:</label>
                         <input type="text" class="form-control"  maxlength="11" placeholder=" " id="vCPF" name="vCPF" value="">
                </div>
  	           </div>
               <div class="form-row">
  		           <div class="col form-group">
  			              <label>Órgão Exp:</label>
  		  	               <input type="text" class="form-control" maxlength="40" placeholder="" id="vOrgaoexp" name="vOrgaoexp" value="">
  		           </div>
                 <div class="col form-group">
                     <label>Cartão Cidadão:</label>
                        <input type="text" class="form-control"  maxlength="40" placeholder=" " id="vCrtcid" name="vCrtcid" value="">
                 </div>
                    
                  </div>
                  <div class="form-row">
                     <div class="col form-group">
                          <label>CEP:</label>
                             <input type="text" class="form-control" maxlength="8" placeholder="" id="vCEP" name="vCEP" value="" onblur="pesquisacep(vCEP.value)">
                     </div>
                     <div class="col form-group">
                           <label>Número Residencial:</label>
                              <input type="text" class="form-control"  maxlength="4" placeholder=" " id="vNumero" name="vNumero" value="">
                     </div>
                   </div>
                   <div class="form-row">
                     <div class="col form-group">
                          <label>Rua:</label>
                             <input type="text" class="form-control"  maxlength="40" placeholder=" " id="vRua" readonly="readonly" name="vRua" value="">
                    </div>
                      
                     <div class="col form-group">
                          <label>Bairro:</label>
                             <input type="text" class="form-control" maxlength="40" placeholder="" id="vBairro" readonly="readonly"  name="vBairro" value="">
                     </div>
                    </div>
                    <div class="form-row">
                       <div class="col form-group">
                            <label>Cidade:</label>
                               <input type="text" class="form-control" maxlength="40" placeholder="" id="vCidade" readonly="readonly" name="vCidade" value="">
                       </div>
                       <div class="col form-group">
                            <label>Estado:</label>
                               <input type="text" class="form-control"  maxlength="40" placeholder=" " id="vEstado" readonly="readonly" name="vEstado" value="">
                      </div>
                     </div>
                     <div class="form-row">
                        <div class="col form-group">
                             <label>Telefone Celular:</label>
                                <input type="text" class="form-control" maxlength="10" placeholder="" id="vTelCel" name="vTelCel" value="">
                        </div>
                        <div class="col form-group">
                             <label>Telefone Residencial:</label>
                                <input type="text" class="form-control"  maxlength="40" placeholder=" " id="vTelResi" name="vTelResi" value="">
                       </div>
                      </div>

                      <input type="checkbox" value="" checked id="check"> Ao clicar "Cadastre-se", você aceita os <a href="#exampleModalScrollable" data-toggle="modal" data-target="#exampleModalScrollable">Termos e a Política de Privacidade</input></a>
                      <br><br>
                      <div class="row">
                        <div class="col-md-2">
                          <button type="button" class="btn btn-primary btn-block" onclick="FrmValidaCadastro()"> Cadastre-se</button>
                        </div>
                        <div class="col-md-2">
                        <a href="./index.php?selec="><button type="button" class="btn btn-primary btn-block" >Cancelar</button></a>
                        </div>
                    </div>
          </form>
          <div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalScrollableTitle">Termos e a Política de Privacidade</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <h2>Política de privacidade para <a href='http://Prontuariodigitaltcc.000webhostapp.com/'>Prontuário Digital</a></h2><p>Todas as suas informações pessoais recolhidas, serão usadas para o ajudar a tornar a sua visita no nosso site o mais produtiva e agradável possível.</p><p>A garantia da confidencialidade dos dados pessoais dos utilizadores do nosso site é importante para o Prontuário Digital.</p><p>Todas as informações pessoais relativas a membros, assinantes, clientes ou visitantes que usem o Prontuário Digital serão tratadas em concordância com a Lei da Proteção de Dados Pessoais de 26 de outubro de 1998 (Lei n.º 67/98).</p><p>A informação pessoal recolhida pode incluir o seu nome, e-mail, número de telefone e/ou telemóvel, morada, data de nascimento e/ou outros.</p><p>O uso do Prontuário Digital pressupõe a aceitação deste Acordo de privacidade. A equipa do Prontuário Digital reserva-se ao direito de alterar este acordo sem aviso prévio. Deste modo, recomendamos que consulte a nossa política de privacidade com regularidade de forma a estar sempre atualizado.</p><h2>Os anúncios</h2><p>Tal como outros websites, coletamos e utilizamos informação contida nos anúncios. A informação contida nos anúncios, inclui o seu endereço IP (Internet Protocol), o seu ISP (Internet Service Provider, como o Sapo, Clix, ou outro), o browser que utilizou ao visitar o nosso website (como o Internet Explorer ou o Firefox), o tempo da sua visita e que páginas visitou dentro do nosso website.</p><h2>Cookie DoubleClick Dart</h2><p>O Google, como fornecedor de terceiros, utiliza cookies para exibir anúncios no nosso website;</p><p>Com o cookie DART, o Google pode exibir anúncios com base nas visitas que o leitor fez a outros websites na Internet;</p><p>Os utilizadores podem desativar o cookie DART visitando a Política de <a href='http://politicaprivacidade.com/' title='privacidade da rede de conteúdo'>privacidade da rede de conteúdo</a> e dos anúncios do Google.</p><h2>Os Cookies e Web Beacons</h2><p>Utilizamos cookies para armazenar informação, tais como as suas preferências pessoas quando visita o nosso website. Isto poderá incluir um simples popup, ou uma ligação em vários serviços que providenciamos, tais como fóruns.</p><p>Em adição também utilizamos publicidade de terceiros no nosso website para suportar os custos de manutenção. Alguns destes publicitários, poderão utilizar tecnologias como os cookies e/ou web beacons quando publicitam no nosso website, o que fará com que esses publicitários (como o Google através do Google AdSense) também recebam a sua informação pessoal, como o endereço IP, o seu ISP, o seu browser, etc. Esta função é geralmente utilizada para geotargeting (mostrar publicidade de Lisboa apenas aos leitores oriundos de Lisboa por ex.) ou apresentar publicidade direcionada a um tipo de utilizador (como mostrar publicidade de restaurante a um utilizador que visita sites de culinária regularmente, por ex.).</p><p>Você detém o poder de desligar os seus cookies, nas opções do seu browser, ou efetuando alterações nas ferramentas de programas Anti-Virus, como o Norton Internet Security. No entanto, isso poderá alterar a forma como interage com o nosso website, ou outros websites. Isso poderá afetar ou não permitir que faça logins em programas, sites ou fóruns da nossa e de outras redes.</p><h2>Ligações a Sites de terceiros</h2><p>O Prontuário Digital possui ligações para outros sites, os quais, a nosso ver, podem conter informações / ferramentas úteis para os nossos visitantes. A nossa política de privacidade não é aplicada a sites de terceiros, pelo que, caso visite outro site a partir do nosso deverá ler a politica de privacidade do mesmo.</p><p>Não nos responsabilizamos pela política de privacidade ou conteúdo presente nesses mesmos sites.</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <script src="js/jquery.mask.min.js"></script>

        <script>
        $("#vData").mask('00/00/0000');
        $("#vRG").mask('99.999.999-9')
        $('#vCPF').mask('000.000.000-00');
        $('#vOrgaoexp').mask('SSS/SS');
        $("#vCrtcid").mask('0.0000000000.00')
        $('#vCEP').mask('00000-000');
        $('#vTelCel').mask('(00) 0000-0000');
        $('#vTelResi').mask('(00) 0000-0000');

        function limpa_formulario_cep() {
            //Limpa valores do formulário de cep.
            document.getElementById('vRua').value=("");
            document.getElementById('vBairro').value=("");
            document.getElementById('vEstado').value=("");
            document.getElementById('vEstado').value=("");
        }

      function meu_callback(conteudo) {
          if (!("erro" in conteudo)) {
              //Atualiza os campos com os valores.
              document.getElementById('vRua').value=(conteudo.logradouro);
              document.getElementById('vBairro').value=(conteudo.bairro);
              document.getElementById('vCidade').value=(conteudo.localidade);
              document.getElementById('vEstado').value=(conteudo.uf);
          } //end if.
          else {
              //CEP não Encontrado.
              limpa_formulario_cep();
              alert("CEP não encontrado.");
              document.getElementById('cep').value=("");
          }
      }
          
      function pesquisacep(valor) {

          //Nova variável "cep" somente com dígitos.
          var cep = valor.replace(/\D/g, '');

          //Verifica se campo cep possui valor informado.
          if (cep !== "") {

              //Expressão regular para validar o CEP.
              var validacep = /^[0-9]{8}$/;

              //Valida o formato do CEP.
              if(validacep.test(cep)) {

                  //Preenche os campos com "..." enquanto consulta webservice.
                  document.getElementById('vRua').value="...";
                  document.getElementById('vBairro').value="...";
                  document.getElementById('vCidade').value="...";
                  document.getElementById('vEstado').value="...";

                  //Cria um elemento javascript.
                  var script = document.createElement('script');

                  //Sincroniza com o callback.
                  script.src = '//viacep.com.br/ws/'+ cep + '/json/?callback=meu_callback';

                  //Insere script no documento e carrega o conteúdo.
                  document.body.appendChild(script);

              } //end if.
              else {
                  //cep é inválido.
                  limpa_formulario_cep();
                  alert("Formato de CEP inválido.");
              }
          } //end if.
          else {
              //cep sem valor, limpa formulário.
              limpa_formulario_cep();
          }
      }
              


               
    </script>
