<?php
  if (isset($_SESSION["usr_login"])) {
?>
<script src="./js/js_navbar.js"></script>
<form name="frmNavbar" id="frmNavbar" method="POST" action="">
  <div class="navigation-wrap bg-light start-header start-style">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="navbar navbar-expand-md navbar-light">

            <a class="navbar-brand" href="./index.php?selec="><img src="./Imgs/PD.png" alt=""></a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav ml-auto py-4 py-md-0">
                <li class="nav-item pl-4 pl-md-0 ml-0 ml-md-4 active">
                  <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Prontuário Digital</a>
                  <div class="dropdown-menu">
                    <a class="dropdown-item" href="./index.php?selec=">Home</a>
                    <a class="dropdown-item" href="./index.php?selec=saud">Minha Saúde</a>
                    <a class="dropdown-item" href="./index.php?selec=map">Medicamentos</a>
                    <a class="dropdown-item" href="./index.php?selec=map">Atendimento</a>
                    <a class="dropdown-item" href="./index.php?selec=map">Hospitais</a>
                  </div>
                </li>
                <li class="nav-item pl-4 pl-md-0 ml-0 ml-md-4">
                  <a class="nav-link" href="./index.php?selec=saud">Meu Histórico</a>
                </li>
                <li class="nav-item pl-4 pl-md-0 ml-0 ml-md-4">
                  <a class="nav-link" href="./index.php?selec=agd">Agenda</a>
                </li>
                <li class="nav-item pl-4 pl-md-0 ml-0 ml-md-4">
                  <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION["usr_login"]; ?><img src="./Imgs/icons/user.png" class="rounded-circle user_photo"></a>
                  <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Gerenciar conta</a>
                    <a class="dropdown-item" onclick="fnLogout()">Sair<img src="./Imgs/icons/logout.png" class="dropdown-icon" onclick="fnLogout()"></a>
                  </div>
                </li>
              </ul>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </div>
</form>

<script type="text/javascript">
  
  function fnLogout() {
    document.frmNavbar.action='./Pages-n-user/classes/logout.php';
    document.frmNavbar.submit();
    return false;
  }

</script>

<style type="text/css">
  .dropdown-item:hover 
  {
    cursor: pointer;
  }
  .dropdown-icon:hover 
  {
    cursor: pointer;
  }
</style>
 
<?php 
  }
  else {
?>  

<div class="navigation-wrap bg-light start-header start-style">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <nav class="navbar navbar-expand-md navbar-light">

          <a class="navbar-brand" href="./index.php?selec="><img src="./Imgs/logo_texto.png" alt=""></a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto py-4 py-md-0">

              <li class="nav-item pl-4 pl-md-0 ml-0 ml-md-4 <?php if ($_REQUEST["selec"] == ""){echo ("active");}?>">
                <a class="nav-link" href="./index.php?selec=" aria-haspopup="true">Home</a>
              </li>
              
              <li class="nav-item pl-4 pl-md-0 ml-0 ml-md-4 <?php if ($_REQUEST["selec"] == "f"){echo ("active");}?>">
                <a class="nav-link" href="./index.php?selec=f">Funcionalidades</a>
              </li>
              <li class="nav-item pl-4 pl-md-0 ml-0 ml-md-4 <?php if ($_REQUEST["selec"] == "s"){echo ("active");}?>">
                <a class="nav-link" href="./index.php?selec=s">Sobre</a>
              </li>
              <li class="nav-item pl-4 pl-md-0 ml-0 ml-md-4 <?php if ($_REQUEST["selec"] == "c"){echo ("active");}?>">
                <a class="nav-link" href="./index.php?selec=c">Contato</a>
              </li>

              <li class="nav-item pl-4 pl-md-0 ml-0 ml-md-4">
                <a class="nav-link" href="#loginModal" data-toggle="modal">Login<img src="./Imgs/icons/user.png" class="rounded-circle user_photo"></a>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  </div>
</div>

<?php  
} 
?>  


