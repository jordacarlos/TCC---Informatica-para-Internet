
<a id="back-to-top" href="#" class="back-to-top" role="button" title="Click to return on the top page" data-toggle="tooltip" data-placement="left"> <span class="glyphicon glyphicon-chevron-up"><img src="imgs/icons/upwards-arrow.png" style=" width: 50px; "></span></a>
	    
        
	</div>

<style type="text/css">
  
  .back-to-top {
    cursor: pointer;
    position: fixed;
    bottom: 20px;
    right: 20px;
    display:none;
    z-index: 1;
}

</style>

<script type="text/javascript">
  
  $(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 1000);
            return false;
        });
        
        $('#back-to-top').tooltip('show');

});

</script>