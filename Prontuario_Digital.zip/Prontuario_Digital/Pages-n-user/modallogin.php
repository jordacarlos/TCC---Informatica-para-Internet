<div id="loginModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <form class="form" name="frmValidaLogin" id="frmValidaLogin" method="POST" action="index.php?acao=logar">
        <div class="modal-dialog ">
            <div class="modal-content"  style="border-radius: 15px;">
                <div class="modal-header" id="modal-header-css">
                    <h3 style="color: #fff ">Entrar</h3>
                    <img src="./imgs/icons/cancel.png" id="cancel_modal" data-dismiss="modal">
                </div>
                <div class="modal-body col-12">
                    <div class="form-group ">
                        <a href="./index.php?selec=cad" class="float-right" id="a-cad">Ainda não possui conta?</a>
                        <label for="txtuser" id="lblmodal">Nome</label>
                        <input type="text" class="form-control form-control-lg" name="iptlogin_user" id="iptlogin_user" required minlength="3">
                    </div>
                    <div class="form-group ">
                        <label id="lblmodal">Senha</label>
                        <input type="password" class="form-control form-control-lg" name="iptlogin_senha" id="iptlogin_senha" required minlength="5">
                    </div>
                    <div class="custom-control custom-checkbox ">
                        <input type="checkbox" class="custom-control-input" id="rememberMe">
                        <label class="custom-control-label" id="lblcheck" for="rememberMe">Lembrar nesse computador</label>
                    </div>
                    <div class="form-group py-4">
                       <a href="./index.php?selec=cad"><button type="button" class="btn btn-secondary btn-lg col-3">Cadastrar</button></a>
                      <button type="submit" class="btn btn-primary btn-lg float-right col-5">Entrar</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<style type="text/css">
    #modal-header-css
    {
        background-image: linear-gradient(to right, #3458b0,  #3fa3e2);
    }
    #a-cad {
        font-size: 17px;
    }
    #lblmodal{
        font-size: 17px;
        font-weight: bold;
    }
    #lblcheck{
        font-size: 17px;
        font-weight: normal;
    }
    #cancel_modal {
        width: 30px;
    }
    #cancel_modal:hover {
        cursor: pointer;
    }
</style>