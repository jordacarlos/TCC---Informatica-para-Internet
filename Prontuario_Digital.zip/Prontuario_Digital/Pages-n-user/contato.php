<link rel="stylesheet" href="./Scripts/Form-Feedback.css">

<br><br>
		<div class="container-fluid">
			<form name="Feedback" method="POST" action="">
		<div class="container">
			<div class="formBox">
				<form>
						<div class="row">
							<div class="col-sm-12">
								<h1>Entre em contato</h1>
							</div>
						</div>

						<div class="row">
							<div class="col-sm-6">
								<div class="inputBox ">
									<div class="inputText">Nome:</div>
									<input type="text" name="" id="fname" class="input">
								</div>
							</div>

							<div class="col-sm-6">
								<div class="inputBox">
									<div class="inputText">Sobrenome:</div>
									<input type="text" name="" id="lname" class="input">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-sm-6">
								<div class="inputBox">
									<div class="inputText">Email</div>
									<input type="text" name="" id="lemail" class="input">
								</div>
							</div>

							<div class="col-sm-6">
								<div class="inputBox">
									<div class="inputText">Telefone:</div>
									<input type="text" name="" id="Ltel" class="input">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-sm-12">
								<div class="inputBox">
									<div class="inputText">Mensagem:</div>
									<textarea class="input" id="Lmsm"></textarea>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-sm-12">
								<input type="submit" name="" class="button" value="Enviar Menssagem" onclick="return verificaFeedback()">
							</div>
						</div>
				</form>
			</div>
		</div>
	</form>
	</div>















        <br><br><br>
		<!-- "RODAPE"-->
		<script src="https://code.jquery.com/jquery-3.2.1.js"></script>
		 <script type="text/javascript">
		 	$(".input").focus(function() {
		 		$(this).parent().addClass("focus");
		 	})
		 </script>
    <script language="JavaScript">
      function verificaFeedback()
      {
        var retorno = false;
        var nome = document.Feedback.fname.value;
        if(document.Feedback.fname.value == null || document.Feedback.fname.value == "")
        {
            alert("Por favor, preencher o campo Nome");
            document.Feedback.fname.focus();
        }
			else if (isNaN(nome)==false) {
				alert("Campo nome com número");
				document.Feedback.fname.focus();
			}
			else if(document.Feedback.lname.value == null || document.Feedback.lname.value == "")
			{
				alert("Por favor, preencher o campo Sobrenome");
				document.Feedback.lname.focus();
			}
			else if (!isNaN(lname)==false) {
				alert("Campo nome com número");
				document.Feedback.lname.focus();
			}
			else if(document.Feedback.lemail.value == null || document.Feedback.lemail.value == "")
			{
				alert("Por favor, preencher o campo Email");
				document.Feedback.lemail.focus();
			}
			else if(document.Feedback.Ltel.value == null || document.Feedback.Ltel.value == "")
			{
				alert("Por favor, preencher o campo telefone");
				document.Feedback.Ltel.focus();
			}
        else
        {
          if(document.Feedback.lname.value == null || document.Feedback.lname.value == "")
          {
            alert("Por favor, preencher o campo Sobrenome");
            document.Feedback.lname.focus();
          }
          else
          {
            if(document.Feedback.lemail.value == null || document.Feedback.lemail.value =="")
            {
              alert("Por favor, preencher o campo E-mail")
              document.Feedback.lemail.focus();
            }
            else
            {
              if(document.Feedback.Lmsm.value == null || document.Feedback.Lmsm.value =="")
              {
                alert("Você esqueceu de nós deixar uma mensagem :)");
                document.Feedback.Lmsm.focus();
              }
              else
              {
                if(document.Feedback.fname.value.length < 3)
                {
                  alert("Por favor, preencher o campo Nome sem nenhum apelido ou abreviação.")
                  document.Feedback.fname.focus();
                }
                else
                {
                  if(document.Feedback.lname.value.length < 3)
                  {
                    alert("Por favor, preencher o campo Sobrenome sem nenhum apelido ou abreviação.");
                    document.Feedback.lname.focus();
                  }
                  else
                  {
                    if (document.Feedback.lemail.value.length < 3)
                    {
                     	alert("Por favor, não programei o email certo ainda :).");
                    	document.Feedback.lemail.focus();
                    }
                    else
                    {
                      if (document.Feedback.Lmsm.value.length < 3)
                      {
                        alert("Na menesagem deixar um comentários maior que 3 caracteres.");
                        document.Feedback.Lmsm.focus();
                        retorno = false;
                      }
                      else
                      {
                        if(retorno == true)
                          {
                            alert("Muito obrigado pelo Feedback sobre o site :)")
                          }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        return retorno;
      }
    </script>
