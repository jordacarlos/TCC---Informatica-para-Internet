<br>
<footer class="page-footer font-small blue" style="background-color:#f0f2f5!important; position: static;
   left: 0; bottom: 0; width: 100%;">
  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2019 Copyright:
    <a href="https://www.vestibulinhoetec.com.br/unidades-cursos/escola.asp?c=31"> Prontuário Digital</a>
  </div>
  <!-- Copyright -->
</footer>

