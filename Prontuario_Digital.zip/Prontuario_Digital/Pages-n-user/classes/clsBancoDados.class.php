<?php

class BancoDados {
	private $host = "localhost";
	//private $user = "alunos";
	private $user = "root";
	private $pass = "etec";
	private $banco = "prontuario_digital";
	public $erro = "";
	private $conexao = "";

	private function Conectar() {
		try {
			$this->conexao = mysqli_connect($this->host,$this->user,$this->pass,$this->banco);
			if(!$this->conexao) {
				$this->erro = "Problema na conexão com o Banco de Dados!";
				return false;
			}
			else {
				//Abrir o banco de dados
				mysqli_select_db($this->conexao,$this->banco);
				$this->erro = "Banco de Dados Conectado!";
				return true;
			}
		}
		catch (Exception $erros) {
			$this->erro = $erros.getMessage();
			return false;
		}
	}
	private function Desconectar() {
		if($this->conexao) {
			//mysqli_close($this->conexao);
			return true;
		}
		else {
			return false;
		}
	}

	public function msgErro()
	{
		return $this->erro;
	}




	public function ExecutarSQL($strSQL){
		try
		{
			$retorno = 0;
			if($this->Conectar())
			{
				$enviarsql= mysqli_query($this->conexao,$strSQL);
				$retorno = mysqli_affected_rows($this->conexao);
			}
			return $retorno;
		}
		catch(Exception $erros)
		{
			$this->erro = $erros.getMessage();
			return 0;
		}
		finally
		{
			$this ->Desconectar();
		}
	}

	public function ConsultarDados($strSQL){
		try
		{
			$retorno = 0;
			if($this->Conectar())
			{
				$enviarsql= mysqli_query($this->conexao,$strSQL);
				if(mysqli_affected_rows($this->conexao)>0)
				{
					$retorno = mysqli_fetch_array($enviarsql);
				 }
			}
			return $retorno;
		}
		catch(Exception $erros)
		{
			$this->erro = $erros.getMessage();
			return null;
		}
		finally
		{
			$this ->Desconectar();
		}
	}

	public function ConsultarDadosQuery($strSQL){
		try
		{
			$retorno = 0;
			if($this->Conectar())
			{
				$enviarsql= mysqli_query($this->conexao,$strSQL);

				if(mysqli_affected_rows($this->conexao)>0)
				{
					$retorno = $enviarsql;
					

				}
			}
			return $retorno;
		}
		catch(Exception $erros)
		{
			$this->erro = $erros.getMessage();
			return null;
		}
		finally
		{
			$this ->Desconectar();
		}
	}




	public function CriarAdministrador()
	{
		try
		{
			$retorno = false;
			if($this->Conectar())
			{
				$comandosql ="select * from usuario where id_user=01 and name_user='Administrador'";
				$enviarsql = $this->ConsultarDados($comandosql);

				if($enviarsql == null)
				{		
					$nome = 'Administrador';
					$login = 'admin';
					$email = 'admin@admin.com.br';
					$senha = sha1(md5("admin")); 

					$comandosql = "insert into usuario (name_user,login_user,email_user,senha_user) value ('$nome','$login','$email','$senha')";
					$enviarsql = $this->ExecutarSQL($comandosql);
					
					if($enviarsql)
					{	
						$retorno = true;
					}
					else
					{
						$this->erro ="Problema na inclusão dos dados da ADMINISTRADOR!";
					}
				}
			return $retorno;
			}
		}
		catch(Exception $erros)
		{
			$this->erro = $erros.getMessage();
			return null;
		}
		finally
		{
			$this ->Desconectar();
		}
	}	


	//**************************************//
	// 			Criação de acesso		    //
	//**************************************//



	public function ValidarAcesso()
	{
		try
		{
			$retorno = false;
			if($this->Conectar())
			{
				$comandosql =  "select * from usuario where login_user='".$this->login."' and senha_user='".$this->senha_login."'";
				$enviarsql = $this->ConsultarDados($comandosql);
				if ($enviarsql!=null)
				{
					$retorno=True;
					$this->erro= "Acesso";
					$enviarsql = $this->ConsultarDados($comandosql);
					$_SESSION["id"] =$enviarsql["id_user"];
					$_SESSION["usr_login"] = $enviarsql["login_user"];
					$_SESSION["usr_name"] = $enviarsql["name_user"];
				}
				else
				{
					$this->erro= "Problemas com o Acesso";
				}
				return $retorno;
			}
		}
		catch(Exception $erros)
		{
			$this->erro = $erros.getMessage();
			return null;
		}
		finally
		{
			$this ->Desconectar();
		}
	}
	

	public function Cadastro() {
		try
		{
			$retorno = false;
			if($this->Conectar())
			{
				$NomeCad = $this->NomeCad;
				$SobNomeCad = $this->SobNomeCad;
				$DataCad = $this->DataCad;
				$SexoCad = $this->SexoCad;
				$LoginCad = $this->LoginCad;
				$SenhaCad = $this->SenhaCad;
				$EmailCad = $this->EmailCad;
				$RgCad = $this->RgCad;
				$CpfCad = $this->CpfCad;
				$OrgaoCad = $this->OrgaoCad;
				$CidadaniaCad = $this->CidadaniaCad;
				$CepCad = $this->CepCad;
				$NumeroCad = $this->NumeroCad;
				$RuaCad = $this->RuaCad;
				$BairroCad = $this->BairroCad;
				$CidadeCad = $this->CidadeCad;
				$EstadoCad = $this->EstadoCad;
				$Tel_CelCad = $this->Tel_CelCad;
				$Tel_ResidCad = $this->Tel_ResidCad;

				$comandosql =  "select * from usuario where login_user='$LoginCad'";
				$enviarsql = $this->ConsultarDados($comandosql);

				if ($enviarsql==null)
				{
					$comandosql =  "insert into usuario (name_user,sobname_user,data_user,sexo_user,login_user,email_user,senha_user,rg_user,cpf_user,orgao_exp,cart_cidad,cep_user,numero_user,rua_user,bairro_user,cidade_user,estado_user,tel_cel,tel_resid) value ('$NomeCad','$SobNomeCad','$DataCad','$SexoCad','$LoginCad','$EmailCad','$SenhaCad','$RgCad','$CpfCad','$OrgaoCad','$CidadaniaCad','$CepCad','$NumeroCad','$RuaCad','$BairroCad','$CidadeCad','$EstadoCad','$Tel_CelCad','$Tel_ResidCad')";
					$enviarsql = $this->ExecutarSQL($comandosql);
				
					if ($enviarsql) {
						$retorno = true;
					}

				}
				else
				{
					$this->erro= "Problemas com o Acesso";
				}

				return $retorno;
			}
		}
		catch(Exception $erros)
		{
			$this->erro = $erros.getMessage();
			return null;
		}
		finally
		{
			$this ->Desconectar();
		}
	}
		
	public function addConsultasHist() {
		try
		{
			$retorno = false;
			if($this->Conectar())
			{
				$id = $this->id;
				$exame = $this->exame;
				$data = $this->data;
				$resultado = $this->resultado;
				$realizado = $this->realizado;

				$comandosql =  "select into consulta where id_consu='$id'";
				$enviarsql = $this->ExecutarSQL($comandosql);		
				
				if ($enviarsql) {  
					$comandosql =  "update consulta set nome_consu='$exame',data_consu='$data',resut_consu='$resultado',realiz_consu='$realizado' where id_consu='$id'";
					$enviarsql = $this->ExecutarSQL($comandosql);	
				}
				else 
				{
					$comandosql =  "insert into consulta (nome_consu,data_consu,resut_consu,realiz_consu) value ('$exame','$data','$resultado','$realizado')";
					$enviarsql = $this->ExecutarSQL($comandosql);		
				}
					
				if ($enviarsql) 
				{
					$retorno = true;
	
				}
				else
				{
					$this->erro= "Problemas com o Acesso";
				}

				return $retorno;
			}
		}
		catch(Exception $erros)
		{
			$this->erro = $erros.getMessage();
			return null;
		}
		finally
		{
			$this ->Desconectar();
		}
	}

	public function delConsultasHist() {
		try
		{
			$retorno = false;
			if($this->Conectar())
			{
				$id = $this->id;
				$exame = $this->exame;
				$data = $this->data;
				$resultado = $this->resultado;
				$realizado = $this->realizado;

				$comandosql =  "select into consulta where id_consu='$id'";
				$enviarsql = $this->ExecutarSQL($comandosql);		
				
				if ($enviarsql) {  
					$comandosql =  "delete from consulta where id_consu='$id'";
					$enviarsql = $this->ExecutarSQL($comandosql);	
									
					if ($enviarsql) 
					{
						$retorno = true;
					}
					else
					{
						$this->erro= "Problemas com o Acesso";
					}
				}
				return $retorno;
			}
		}
		catch(Exception $erros)
		{
			$this->erro = $erros.getMessage();
			return null;
		}
		finally
		{
			$this ->Desconectar();
		}
	}
	public function ViewConsultasHist($strSQL) {
		try
		{
			$retorno = false;
			if($this->Conectar())
			{
				
				$enviarsql = $this->ConsultarDadosQuery($strSQL);			
					
				if ($retorno != 0) 
				{
					$retorno = $enviarsql;
	
				}
				else
				{
					$this->erro= "Problemas com o Acesso";
				}

				return $retorno;
			}
		}
		catch(Exception $erros)
		{
			$this->erro = $erros.getMessage();
			return null;
		}
		finally
		{
			$this ->Desconectar();
		}
	}
}