<?php
	if(!session_id()) {
		session_start();
	}
	if(!isset($_SESSION["id"])) {
		//Variavel de sessao para validar se o usuario está logado
		$_SESSION["id"] = "";
	}
?>