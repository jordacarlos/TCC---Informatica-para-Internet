<?php
	session_start();
	$_SESSION["id"] = "";
	session_destroy();
	echo "<script>window.location.href='../../index.php?selec=';</script>";
?>