<?php 

  require_once("./Pages-n-user/classes/clsBancoDados.class.php");
  require_once("./Pages-n-user/classes/conf_sessao.php");

  $objBD = new BancoDados();
  //exit;
  $acao = "";
  $msgerro = "";
  $validar = "";

  if($_POST) {
    //Validar se o parâmetro ACAO existe
    if(isset($_REQUEST  ["acao"])) {
      if($_REQUEST["acao"] != "") {
        $acao = $_REQUEST["acao"];
      }
    }
    
    if($acao == "logar") 
    {
      $objBD->login = $_REQUEST["iptlogin_user"];
      $objBD->senha_login = sha1(md5($_REQUEST["iptlogin_senha"]));
      
      if($objBD->ValidarAcesso())
      {
        $msgerro = "Usuário logado";
      }
      else
      {
        $msgerro="Usuário não Logado!";
        echo "<script>alert('Usuario ou senha errados');</script>";
      }
    }
    if($acao == "cadastro")
    {
      $objBD->NomeCad = $_REQUEST["vNome"];
      $objBD->SobNomeCad = $_REQUEST["vLNome"];
      $objBD->DataCad = $_REQUEST["vData"];
      $objBD->SexoCad = $_REQUEST["vSexo"];
      $objBD->LoginCad = $_REQUEST["vLogin"];
      $objBD->SenhaCad = sha1(md5($_REQUEST["vSenha"]));
      $objBD->EmailCad = $_REQUEST["vEmail"];
      $objBD->RgCad = $_REQUEST["vRG"];
      $objBD->CpfCad = $_REQUEST["vCPF"];
      $objBD->OrgaoCad = $_REQUEST["vOrgaoexp"];
      $objBD->CidadaniaCad = $_REQUEST["vCrtcid"];
      $objBD->CepCad = $_REQUEST["vCEP"];
      $objBD->NumeroCad = $_REQUEST["vNumero"];
      $objBD->RuaCad = $_REQUEST["vRua"];
      $objBD->BairroCad = $_REQUEST["vBairro"];
      $objBD->CidadeCad = $_REQUEST["vCidade"];
      $objBD->EstadoCad = $_REQUEST["vEstado"];
      $objBD->Tel_CelCad = $_REQUEST["vTelCel"];
      $objBD->Tel_ResidCad = $_REQUEST["vTelResi"];

      if($objBD->Cadastro())
      {
        echo "<script>alert('Usuário Criado!')</script>";
      }
      else
      {
        echo "<script>alert('Nome de Usuário já existe')</script>";
        echo "<script>history.back();</script>";
      }
    }
    if ($acao == "addhist")
    {
      echo "<script>history.back();</script>";
      $objBD->id = addslashes($_POST['campo_0']);
      $objBD->exame = addslashes($_POST['campo_1']);
      $objBD->data = addslashes($_POST['campo_2']);
      $objBD->resultado = addslashes($_POST['campo_3']);
      $objBD->realizado = addslashes($_POST['campo_4']);
      
      if($objBD->addConsultasHist())
      {}
    }
    if ($acao == "delhist")
    {
      echo "<script>history.back();</script>";
      $objBD->id = addslashes($_POST['campo_0']);
      $objBD->exame = addslashes($_POST['campo_1']);
      $objBD->data = addslashes($_POST['campo_2']);
      $objBD->resultado = addslashes($_POST['campo_3']);
      $objBD->realizado = addslashes($_POST['campo_4']);
      
      if($objBD->delConsultasHist())
      {}
    }

  }

  else 
  {
    if($objBD-> CriarAdministrador())
    {
      $msgerro = "Usuario ADMIN criado com sucesso";
    }
    else
    {
      $msgerro = "Falha ao criar admin";
    }
  } 
 ?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title> Prontuário Digital </title>
    
    <link rel="shortcut icon" type="image/x-icon" href="./Imgs/PD.png">
    <link href="./Scripts/OpenSansFont.css" rel="stylesheet">   
    <link href="./Scripts/principal.css" rel="stylesheet">
    <link href="./css/bootstrap.min.css" rel="stylesheet">
    <link href="./Scripts/style_navbar.css" rel="stylesheet">
    <script src="./js/jquery.min.js"></script>
    <script src="./js/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/jquery.mask.min.js"></script>
    
  </head>
  <body>
 <?php
     
    require_once("./Pages-n-user/navbar.php");
    require_once("./Pages-n-user/btn_subir_pagina.php");

    if ($_SESSION["id"] == ""){
      require_once("./Pages-n-user/modallogin.php");
      
      if (!isset($_REQUEST["selec"])){
        require_once("./Pages-n-user/home.php");
      }

      else if (isset($_REQUEST["selec"])){
        if ($_REQUEST["selec"] == "") {
          require_once("./Pages-n-user/home.php");
        }
        if ($_REQUEST["selec"] == "f") {
          require_once("./Pages-n-user/func.php");
        }
        if ($_REQUEST["selec"] == "s") {
          require_once("./Pages-n-user/sobre.php");
        }
        if ($_REQUEST["selec"] == "c") {
          require_once("./Pages-n-user/contato.php");
        }
        if($_REQUEST["selec"]=="cad")
        {
          require_once("./pages-n-user/cadastro.php");
        }
      }
    }
    else {
      if (!isset($_REQUEST["selec"]))
      {
        require_once("./Pages-user/bem-vindo.php");
        require_once("./Pages-user/funcionalidade.php");
        require_once("./Pages-user/campanhas.php");
      }

      else if (isset($_REQUEST["selec"]))
      {
        if ($_REQUEST["selec"] == "") 
        {
          require_once("./Pages-user/bem-vindo.php");
          require_once("./Pages-user/funcionalidade.php");
          require_once("./Pages-user/campanhas.php");
        }
        if ($_REQUEST["selec"] == "map") 
        {
          require_once("./Pages-user/mapas.php");
        }
        if ($_REQUEST["selec"] == "agd") 
        {
          require_once("./Pages-user/agenda.php");
        }
        if ($_REQUEST["selec"] == "saud") 
        {
          require_once("./Pages-user/saude2.php");
        }
        
      }
    }
      
    require_once("./Pages-n-user/footer.php");
    ?>
    
      </body>
</html>
