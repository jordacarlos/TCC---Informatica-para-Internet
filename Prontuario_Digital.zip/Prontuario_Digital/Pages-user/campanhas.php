<link href="./Scripts/campanhas.css" rel="stylesheet">


<!-- Include the above in your HEAD tag ---------->
<br><br><br>

<h1 class="text-center">Campanhas para ficar de olho</h1>
<br><br>


	<div class="container">
	<div class="row">

	<!--campanha-1-->
	<div class="col-lg-4">
	<div class="campanha-main">

	<div class="campanha-ft">
	<img src="./Imgs/campanhas/Laço-Vermelho-Campanhas.png" class="img-fluid" />
	<h3>Junho Vermelho</h3>
	<p>Doe sangue</p>
	</div>

	<div class="campanha-text">
	<span>
	No dia 14 de junho é celebrado o dia Mundial do doador de Sangue, por isso a escolha desse mês para conscientizar sobre a importância da doação.
	Doe você também!
	</span>
	<center><a href="https://www.calendarr.com/brasil/dia-mundial-do-doador-de-sangue/" target="_blank" class="campanha-a">Saber mais</a></center>
	</div>

	</div>
	</div>
	<!--campanha-1-->

	<!--campanha-2-->
	<div class="col-lg-4">
	<div class="campanha-main">

	<div class="campanha-ft">
	<img src="./Imgs/campanhas/Laço-Laranja-Campanhas.png" class="img-fluid" />
	<h3>Junho Laranja</h3>
	<p>Anemia a leucemia</p>
	</div>

	<div class="campanha-text">
	<span>
	A iniciativa foi criada pelo movimento Eu Sou Sangue, em 2011, e alerta para a anemia e a leucemia os riscos dessas doenças que por vezes não tem tanta atenção como deveriam.
	</span>
	<center><a href="http://www.abcdoabc.com.br/brasil-mundo/noticia/junho-laranja-alerta-leucemia-82791" target="_blank" class="campanha-a">Saber mais</a></center>
	</div>

	</div>
	</div>
	<!--campanha-2-->

	<!--campanha-3-->
	<div class="col-lg-4">
	<div class="campanha-main">

	<div class="campanha-ft">
	<img src="./imgs/campanhas/Junho-Violeta-Campanha.png" class="img-fluid" />
	<h3>Junho violeta</h3>
	<p>Violência contra a Pessoa Idosa</p>
	</div>

	<div class="campanha-text">
	<span>
	O objetivo da data é criar uma consciência mundial, social e política da existência da violência contra a pessoa idosa, e, simultaneamente, disseminar a idéia de não aceitá-la como normal.
	</span>
	<center><a href="https://dppa.jusbrasil.com.br/noticias/1328618/15-de-junho-dia-mundial-de-conscientizacao-da-violencia-contra-a-pessoa-idosa" target="_blank" class="campanha-a">Saber mais</a></center>
	</div>

	</div>
	</div>
	<!--campanha-3-->

	<!--campanha-4-->
	<div class="col-lg-4">
	<div class="campanha-main">

	<div class="campanha-ft">
	<img src="./Imgs/campanhas/Drogas-Campanha.jpg" class="img-fluid" />
	<h3>Combate contra as drogas</h3>
	<p>Combata você também</p>
	</div>

	<div class="campanha-text">
	<span>
Atualmente o uso e abuso de álcool e outras drogas constituem um dos mais importantes problemas de saúde pública no mundo,
todo ano 210 milhões de pessoas usem drogas ilícitas no mundo, das quais quase 200 mil morrem anualmente.
	</span>
	<center><a href="https://www.calendarr.com/brasil/dia-internacional-contra-o-abuso-e-trafico-ilicito-de-drogas/" target="_blank" class="campanha-a">Saber mais</a></center>
	</div>
	</div>
	</div>
	<!--campanha-4-->

	<!--campanha-5-->
	<div class="col-lg-4">
	<div class="campanha-main">

	<div class="campanha-ft">
	<img src="./Imgs/campanhas/tortura-campanha.png"  class="img-fluid" />
	<h3>Apoio às Vítimas da Tortura</h3>
	<p>Tortura é crime</p>
	</div>

	<div class="campanha-text">
	<span>
		São organizadas diversas atividades e atos que ajudam a promover a criação de condições necessárias para que haja o suporte solidário, material, jurídico e psicológico às vítimas de maus-tratos.
	</span>
	<center><a href="https://www.calendarr.com/brasil/dia-internacional-de-apoio-as-vitimas-de-tortura/" target="_blank" class="campanha-a" >Saber mais</a></center>
	</div>

	</div>
	</div>
	<!--campanha-5-->

	<!--campanha-6-->
	<div class="col-lg-4">
	<div class="campanha-main">

	<div class="campanha-ft">
	<img src="./Imgs/campanhas/asma-Campanha.png" class="img-fluid" />
	<h3>Controle da Asma</h3>
	<p>Ajude nessa causa</p>
	</div>

	<div class="campanha-text">
	<span>
	A campanha contra a asma, lançada na terça-feira (7) como parte do Dia Mundial da Asma, defende a prevenção e conscientização como a forma mais eficaz de combatê-la.O tema neste ano é ‘Pare a Asma‘ (Stop for Asthma, em inglês).
	</span>
	<center><a href="http://agenciabrasil.ebc.com.br/saude/noticia/2019-05/campanha-defende-prevencao-e-conscientizacao-para-combater-asma" target="_blank" class="campanha-a">Saber mais</a></center>
	</div>

	</div>
	</div>
	<!--campanha-6-->



	</div>
	</div>

