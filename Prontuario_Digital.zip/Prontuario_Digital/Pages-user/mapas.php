<br><br><br><br><br>
<center>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3676.1131370424796!2d-47.21240988503495!3d-22.87227868502939!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94c8b9576bd03a93%3A0xb652b12256f924!2sETEC+de+Hortol%C3%A2ndia!5e0!3m2!1spt-BR!2sbr!4v1560606445285!5m2!1spt-BR!2sbr" width="80%" height="650" frameborder="0" style="border:0" allowfullscreen></iframe>
</center>

<style type="text/css">
	
	body {
		background-color: #e9e9e9;
	}

</style>