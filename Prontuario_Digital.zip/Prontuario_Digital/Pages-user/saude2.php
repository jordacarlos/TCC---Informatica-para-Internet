<br><br><br><br><br>
<div class="container col-12">
<div class="row">
    <div class="col-1">
    </div>
  <div class="col-2">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-consultas" role="tab" aria-controls="v-pills-home" aria-selected="true">&nbsp;&nbsp;&nbsp;Minhas Consultas</a>
      <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">&nbsp;&nbsp;&nbsp;Minhas Alergias</a>
      <a class="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">&nbsp;&nbsp;&nbsp;Meu Histórico de Doenças</a>
    </div>
  </div>
  <div class="col-8">
    <div class="tab-content" id="v-pills-tabContent">
      <div class="tab-pane fade show active" id="v-pills-consultas" role="tabpanel" aria-labelledby="v-pills-consultas-tab">
      <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2>Meus Exames Médicos</h2></div>
                    <div class="col-sm-4">
                        <button type="button" class="btn btn-info add-new"><i class="fa fa-plus"></i> Adicionar</button>
                    </div>
                </div>
            </div>
            <form action = '' method = 'post' id = 'form'>
            <table class="table table-bordered col-12">
                <thead>
                    <tr>
                        <th class="col-1">Id:</th>
                        <th class="col-3">Exame:</th>
                        <th class="col-1">Data:</th>
                        <th class="col-1">Resultado:</th>
                        <th class="col-1">Realizado?</th>
                        <th class="col-1">Ações</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    $cont = 0;
                    $comandosql = 'select id_consu, nome_consu, data_consu, resut_consu, realiz_consu FROM consulta';
                    
                    $consulta = $objBD->ConsultarDadosQuery($comandosql);

                    foreach ($consulta as $valor) {
                        //var_dump($valor);
                         # code...
                    ?>
                        <tr>
                            <td class="col-1"><?php echo $valor['id_consu']; ?></td>
                            <td><?php echo $valor['nome_consu']; ?></td>
                            <td><?php echo $valor['data_consu']; ?></td>
                            <td><?php echo $valor['resut_consu']; ?></td>                                                 
                            <td><?php echo $valor['realiz_consu']; ?></td>                                                 
                            <td>
                                <a class="add" title="Add" data-toggle="tooltip" onclick="fnAdd()"><i class="material-icons" >&#xE03B;</i></a>
                                <a class="edit" title="Edit" data-toggle="tooltip" onclick="fnShowDel()"><i class="material-icons">&#xE254;</i></a>
                                <a class="delete" title="Delete" data-toggle="tooltip" onclick="fnDel()" <?php if ($cont=0){ echo 'style="display: none;"';} ?>><i class="material-icons">&#xE872;</i></a>
                            </td>
                        </tr>
                     
                <?php  } ?>

                </tbody>
            </table>
        </form>
        </div>
      </div>

      <!-- Alergias -->
      <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">

        <div id="accordion">

            <div class="card">
                <div class="card-header">
                  <a class="card-link" data-toggle="collapse" href="#collapseOne" style="color: black;">
                    Alergias á Remédios
                  </a>
                </div>
                <div id="collapseOne" class="collapse show" data-parent="#accordion">
                  <div class="card-body">
                    <table class="table table-bordered">
                        <tr>
                            <td>Bactrim</td>
                        </tr>
                        <tr>
                            <td>Cetoprofeno</td>
                        </tr>
                        <tr>
                            <td>Penicilina</td>
                        </tr>
                        <tr>
                            <td>Carbamazepina</td>
                        </tr>
                        <tr>
                            <td>Ibuprofeno</td>
                        </tr>
                        <tr>
                            <td>Fenitoína</td>
                        </tr>
                        <tr>
                            <td>Atracúrio</td>
                        </tr>
                        <tr>
                            <td>Atracúrio</td>
                        </tr>
                        <tr>
                            <td>Eritromicina</td>
                        </tr>
                        <tr>
                            <td>Amoxicilina</td>
                        </tr>
                    </table>
                  </div>
                </div>
                </div>

                <div class="card">
                <div class="card-header">
                  <a class="collapsed card-link" data-toggle="collapse" href="#collapseTwo" style="color: black;">
                    Alergias alimentares
                  </a>
                </div>
                <div id="collapseTwo" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <table class="table table-bordered">
                        <tr>
                            <td>Glúten</td>
                        </tr>
                        <tr>
                            <td>Camarão</td>
                        </tr>
                        <tr>
                            <td>Caranguejo</td>
                        </tr>
                        <tr>
                            <td>Lagosta</td>
                        </tr>
                        <tr>
                            <td>Tomate</td>
                        </tr>
                        <tr>
                            <td>Frutas cítricas</td>
                        </tr>
                        <tr>
                            <td>Ervilha</td>
                        </tr>
                        <tr>
                            <td>Canela</td>
                        </tr>
                    </table>
                  </div>
                </div>
                </div>

                <div class="card">
                <div class="card-header">
                  <a class="collapsed card-link" data-toggle="collapse" href="#collapseThree" style="color: black;">
                    Alergias - Renites/Urticárias
                  </a>
                </div>
                <div id="collapseThree" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                     <table class="table table-bordered">
                        <tr>
                            <td>Pólen</td>
                        </tr>
                        <tr>
                            <td>Mofo</td>
                        </tr>
                        <tr>
                            <td>Poeira</td>
                        </tr>
                    </table>
                  </div>
                </div>
            </div>

            </div> 
      </div>


        <!-- Doenças -->
      <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
        <div class="table-wrapper">

            <table class="table table-bordered col-12">

        <thead>
            <tr>
            <th scope="col">Doença:</th>
            <th scope="col">Data início:</th>
            <th scope="col">Data Término:</th>
            <th scope="col">Sequelas:</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Gripe</td>
                <td>12/04/2019</td>
                <td>17/04/2019</td>
                <td>Nenhuma</td>
            </tr>
            <tr>
                <td>Dermatite</td>
                <td>01/05/2019</td>
                <td>10/05/2019</td>
                <td>Nenhuma</td>
            </tr>
            <tr>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
            </tr>
            <tr>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
            </tr>
            <tr>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
            </tr>
        </tbody>
        </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<script>
  $(function () {
    $('#myTab li:last-child a').tab('show')
  })
</script>


<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<style type="text/css">
    .hide {
        display: none;
    }
	.table-wrapper {
		background: #fff;
        padding: 20px;	
        box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }
    .table-title {
        padding-bottom: 10px;
        margin: 0 0 10px;
    }
    .table-title h2 {
        margin: 6px 0 0;
        font-size: 22px;
    }
    .table-title .add-new {
        float: right;
		height: 30px;
		font-weight: bold;
		font-size: 12px;
		text-shadow: none;
		min-width: 100px;
		border-radius: 50px;
		line-height: 13px;
    }
	.table-title .add-new i {
		margin-right: 4px;
	}
    table.table {
        table-layout: fixed;
    }
    table.table tr th, table.table tr td {
        border-color: #e9e9e9;
    }
    table.table th i {
        font-size: 13px;
        margin: 0 5px;
        cursor: pointer;
    }
    table.table th:last-child {
        width: 100px;
    }
    table.table td a {
		cursor: pointer;
        display: inline-block;
        margin: 0 5px;
		min-width: 24px;
    }    
	table.table td a.add {
        color: #27C46B;
    }
    table.table td a.edit {
        color: #FFC107;
    }
    table.table td a.delete {
        color: #E34724;
    }
    table.table td i {
        font-size: 19px;
    }
	table.table td a.add i {
        font-size: 24px;
    	margin-right: -1px;
        position: relative;
        top: 3px;
    }    
    table.table .form-control {
        height: 32px;
        line-height: 32px;
        box-shadow: none;
        border-radius: 2px;
    }
	table.table .form-control.error {
		border-color: #f50000;
	}
	table.table td .add {
		display: none;
	}
     {

    }
    body {
        background-color: #e9e9e9;
    }

  </style>
<script type="text/javascript">

$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	var actions = $("table td:last-child").html();
	// Append table with add row form on add new button click
    $(".add-new").click(function(){
		$(this).attr("disabled", "disabled");
		var index = $("table tbody tr:last-child").index();
        var row = 
        '<tr>' +
            '<td><input type="text" class="form-control" name="id" id="id"></td>' +
            '<td><input type="text" class="form-control" name="name" id="name"></td>' +
            '<td><input type="text" class="form-control" name="data" id="data"></td>' +
            '<td><input type="text" class="form-control" name="resultado" id="resultado"></td>' +
            '<td><input type="text" class="form-control" name="realizado" id="realizado"></td>' +
			'<td>' + actions + '</td>' + 
        '</tr>'; 
    	$("table").append(row);		
		$("table tbody tr").eq(index + 1).find(".add, .edit").toggle();
        $('[data-toggle="tooltip"]').tooltip();
        
        

        
    });
  	// Add row on add button click
	$(document).on("click", ".add", function(){
		var empty = false;
		var input = $(this).parents("tr").find('input[type="text"]');
        
        input.each(function(){
			if(!$(this).val()){
				$(this).addClass("error");
				empty = true;
			} else{
                $(this).removeClass("error");
            }
            
		});
        
		$(this).parents("tr").find(".error").first().focus();
		if(!empty){
			input.each(function(){
				$(this).parent("td").html($(this).val());
			});			
			$(this).parents("tr").find(".add, .edit").toggle();
			$(".add-new").removeAttr("disabled");
            

		}	
        
    });
	// Edit row on edit button click
	$(document).on("click", ".edit", function(){		
        var cont = 0;
        $(this).parents("tr").find("td:not(:last-child)").each(function(){
			//alert(cont);
            $(this).html('<input type="text" class="form-control" id="campo_'+cont+'" name="campo_'+cont+'" value="' + $(this).text() + '">');
            cont++;
         
			
            
		});		
		$(this).parents("tr").find(".add, .edit").toggle();
		$(".add-new").attr("disabled", "disabled");
        
    });
    
	// Delete row on delete button click
	$(document).on("click", ".delete", function(){
        $(this).parents("tr").remove();
		$(".add-new").removeAttr("disabled");
        
    });
});


function fnAdd() {
    form.action='./index.php?acao=addhist';
    form.submit();

}
function fnDel() {
    form.action='./index.php?acao=delhist';
    form.submit();

}
    


    //alert('teste');

/*
    var elemento0 = document.getElementById('campo_0');
     var elemento1 = document.getElementById('campo_1');
      var elemento2 = document.getElementById('campo_2');
       var elemento3 = document.getElementById('campo_3');
*/
       

       //location.href = 'Pages-user/add.php?exame='+elemento0.value+'&data='+elemento1.value+'&resultado='+elemento2.value+'&realizado='+elemento3.value;


        //alert(input);

        
</script>


                           