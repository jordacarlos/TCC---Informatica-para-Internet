 <div class="container">
 <br>
    <div class="row">
      <div class="col-md-4">
        <center>
        <a href="index.php?selec=saud">
			<div class="card bg-light mb-3 " style="max-width: 18rem;">
				<div class="card-header bg-transparent">
					<img src="./Imgs/func/minha.png" class="imgfunc" alt="Card image cap" width="160" height="160">
				</div>
        </a>
     	<a href="index.php?selec=saud" class="a_card">
				<div class="card-body text">
					<p class="card-title">Meu Histórico</p>
					<p class="card-text">Seu historíco médico</p>
				</div>
		</a>
			</div>
      </center>
      </div>
      <div class="col-md-4">
        <center>
        <a href="index.php?selec=agd">
			<div class="card bg-light mb-3" style="max-width: 18rem;">
				<div class="card-header bg-transparent">
					<img src="./Imgs/func/agenda.png" class="imgfunc" alt="Cinque Terre" width="160" height="160">
				</div>
        </a>
        <a href="index.php?selec=agd" class="a_card">
				<div class="card-body text">
					<p class="card-title">Agenda</p>
					<p class="card-text">Não esqueça de nada</p>
				</div>
		</a>
			</div>
		</center>
      <br>
      </div>
      <div class="col-md-4">
        <center>
		<a href="#">
			<div class="card bg-light mb-3" style="max-width: 18rem;">
				<div class="card-header bg-transparent">
					<img src="./Imgs/func/phone.png" class="imgfunc" alt="Cinque Terre" width="160" height="160">
				</div>
		</a>
     	<a href="index.php?selec=" class="a_card">
				<div class="card-body text">
					<p class="card-title">Ouvidoria</p>
					<p class="card-text">Entre em contato</p>
				</div>
		</a>
				
			</div>
		</center>
      </div>
      <div class="col-md-4">
        <center>
        <a href="index.php?selec=map">
			<div class="card bg-light mb-3" style="max-width: 18rem;">
				<div class="card-header bg-transparent">
					<img src="./Imgs/func/remedio.png" class="imgfunc" alt="Cinque Terre" width="160" height="160">
				</div>
        </a>
        <a href="index.php?selec=map" class="a_card">
				<div class="card-body text">
					<p class="card-title">Medicamentos</p>
					<p class="card-text">Farmácia Populares proxímas</p>
				</div>		
		</a>
			</div>
		</center>
      </div>
      
      <div class="col-md-4">
        <center>
        <a href="index.php?selec=map">
			<div class="card bg-light mb-3" style="max-width: 18rem;">
				<div class="card-header bg-transparent">
					<img src="./Imgs/func/servico.png" class="imgfunc" alt="Cinque Terre" width="160" height="160">
				</div>
        </a>
        <a href="index.php?selec=map" class="a_card">
        		<div class="card-body text" id="cardfunctxt">
					<p class="card-title">Serviços de saúde</p>
					<p class="card-text">Localize um próximo a você</p>
				</div>
		</a>
			</div>
		</center>
      </div>
      <div class="col-md-4">
        <center>
        <a href="index.php?selec=map">
			<div class="card bg-light mb-3" style="max-width: 18rem;">
				<div class="card-header bg-transparent">
					<img src="./Imgs/func/hospitais.png" class="imgfunc" alt="Cinque Terre" width="160" height="160">
				</div>
		</a>
		<a href="index.php?selec=map" class="a_card">
				<div class="card-body text" id="cardfunctxt">
					<p class="card-title">Hospitais</p>
					<p class="card-text">Os hospitais próximo á você</p>
				</div>
		</a>
    		</div>
      	</center>
      </div>
      <br>
      <br>
    </div>
  </div>


<style type="text/css">
.card-title {
	font-size: 22px;
}	
.imgfunc
{
transition: all 0.3s ease;
}
.imgfunc:hover 
{
	width: 170px;
	height: 170px;
	transition: all 0.3s ease;

}
.a_card
{
	text-decoration: none;
	transition: all 0.1s ease;
	color: #424242;
}
.a_card:hover
{
	cursor: pointer;
	text-decoration: none;
	color: #000;
	transition: all 0.2s ease;
}

.card-text
{
	margin-top: -7px;
}

</style>